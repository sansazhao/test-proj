/**
 * Created by 76587 on 2017/7/16.
 */
var formula="";
var number="8";
var preAns;
var input;
var saved="";
var ts;
var decLen=8;
var _x = -10;


function help(){
    var help="欢迎使用计算器，这是一款操作简单的网页计算器。支持加减乘除、取余、正余弦、排列组合、函数绘图功能。\n\n";
    help+="按键解释：\n   =：输入完毕，点击获得运算结果\n   清空：清空输入框\n   退格：撤销一次输入\n   " +
        "Ans:上次的计算结果nCr/nPr:仅支持nCr,nPr的输入方式\n   " +"+/-改变输入开头的正负号（使用情况不多）\n   "
        "绘图方式：点击f(x)=输入函数表达式,x为自变量\n   支持大多数简单函数绘图\n\n";
    alert(help);
}

function toDrawPage(){
    var div1 =document.getElementById("calculator");
    var div2 =document.getElementById("graph");
    var bt =document.getElementById("returnBtn");
    div1.style.display = "none";
    div2.style.display = "block";
    bt.display="block";
    graph();
}

function toCalPage(){
    var div1 =document.getElementById("calculator");
    var div2 =document.getElementById("graph");
    var bt =document.getElementById("returnBtn");
    div2.style.display = "none";
    div1.style.display = "block";
    bt.display="none";
}

function graph(){
    Plot.init("graph",300, 300,'green','red',1);
    var unit=15;
    var x=0;
    var y=0;
    try{
        changeDec();
        for(;x<5000;x++) {
            formula=document.getElementById("inputBox").value;
            formula=formula.slice(5,formula.length);
            input = formula;
            ts = Token_stream.createNew();
            _x += 0.02;
            y = expression();
            Plot.drawDot(_x*unit,y*unit);
        }
        _x = 0.03;
        to_clear();
        saved = "";
    }
    catch (err){
        alert(err);
        to_clear();
    }
}

function show(key){
    var value1=document.getElementById("inputBox").value.split("\n")[0];
    var value2=document.getElementById("inputBox").value.split("\n")[1];
    if(value1 && value2)
        document.getElementById("inputBox").value = value1+key+"\n"+value2;
    else
        document.getElementById("inputBox").value+=key;
}

function to_clear(){
    formula="";
    document.getElementById("inputBox").value="";
    input="";
    saved="";
}

function cancel(){
    formula=document.getElementById("inputBox").value;
    formula=formula.slice(0,formula.length-1);
    document.getElementById("inputBox").value=formula;
}

function equal(){
    try{
        changeDec();
        formula=document.getElementById("inputBox").value.split("\n")[0];
        input = formula;
        ts = Token_stream.createNew();
        var _ans = expression();
        var ce = Math.ceil(_ans);
        if(_ans-ce<0.0000001&&_ans-ce>-0.0000001)
            _ans=ce;
        var _ansf = getResult(_ans,decLen);
        document.getElementById("inputBox").value =formula+ "\n = "+_ansf;
        preAns = parseFloat(_ans);
        saved = "";
    }
    catch (err){
        alert(err);
        to_clear();
    }
}

function ans() {
    //save last answer
    document.getElementById("inputBox").value += "ans";
}

function changeDec(){
    var newDec=document.getElementById("setDecimal");
    var index=newDec.selectedIndex;
    decLen = newDec.options[index].value;
}

function changePN(){
    var former = document.getElementById("inputBox").value;
    var ch = former[0];
    if(ch === "-") {
        to_clear();
        former = former.slice(1, former.length);
    }
    else
        former = "-"+former;
    document.getElementById("inputBox").value = former;
}

function getResult(num, n){
    return num.toString().replace(new RegExp("^(\\-?\\d*\\.?\\d{0,"+n+"})(\\d*)$"),"$1");
}

function Token(ch,val) {
    this.kind = ch;
    this.value = val;
}

var Token_stream = {
    createNew: function () {
        var full = false;
        var buffer = "";
        var token_stream = {};
        token_stream.get = function () {
            var ch;
            if (full) {   //have a Token ready?remove Token from buffer
                full = false;
                return buffer;
            }
            if (input.length === 1) {
                ch = input;
                input = "";
            }
            else if(input === "")
                return new Token("",0);
            else {
                ch = input[0];
                input = input.slice(1, input.length);
            }
            switch (ch) {
                case"(":
                case")":
                case"+":
                case"-":
                case"*":
                case"/":
                case"%":
                case"!":
                case"^":
                case"C":
                case"P":
                case"|":
                    return new Token(ch, 0);
                case".":
                case"0":
                case"1":
                case"2":
                case"3":
                case"4":
                case"5":
                case"6":
                case"7":
                case"8":
                case"9": {
                    input = ch + input;
                    saved = parseFloat(input);
                    input = input.slice(saved.toString().length, input.length);
                    return new Token(number, saved);
                }
                case"p": {
                    if(input[0]==="i") {
                        input = input.slice(1, input.length);
                        return new Token(number, 3.1415926535);
                    }
                    throw("输入了无效字符："+input[0]+"，请重新输入");
                }
                case"e":
                    return new Token(number, 2.7182818284);
                case"s":case"c":  //sin(、sqrt(
                    ch = input[2];
                    input = input.slice(3, input.length);
                    if (ch === "(")
                        return new Token(ch, 0);
                    return new Token("k", 0);
                case"l":
                    ch = input[0];
                    input = input.slice(1, input.length);
                    return new Token(ch, 0);
                case"a": {
                    var check = input.slice(0, 2);
                    input = input.slice(2, input.length);
                    if (check === "ns")
                        return new Token(number, preAns);
                    else
                        throw("算式无法运算，请重新输入");
                }
                case"x":
                    return new Token(number,_x);
                default:
                    throw("算式无法运算，请重新输入");
            }
        };
        token_stream.putback = function (t){
            if (full)
                throw("putback into a full buffer");
            buffer = t;  //copy t to buffer
            full = true;
        };
        return token_stream;
    }
};


function num(){
    //deal with number , () ,|n|, sin(n)
    var t = ts.get();
    switch (t.kind) {
        case"(": {	//()
            var d = expression();
            t = ts.get();
            if (t.kind !== ")")
                throw("算式缺少），请重新输入");
            return d;
        }
        case"s": {	// sin(x)
            var d = expression();
            t = ts.get();
            if (t.kind !== ")")
                throw("算式缺少），请重新输入");
            return Math.sin(d);
        }
        case"c": {	// sin(x)
            var d = expression();
            t = ts.get();
            if (t.kind !== ")")
                throw("算式缺少），请重新输入");
            return Math.cos(d);
        }
        case"|": { // absolute value
            var d = expression();
            t = ts.get();
            if (t.kind !== "|")
                throw("算式缺少|，请重新输入");
            if (d >= 0)
                return d;
            return -d;
        }
        case number:
            return t.value;
        default:
            throw("算式无法运算，请重新输入");
    }
}

function factorial() {
    //deal with n! (-170 <= n <= 170)
    var left = Number(num());
    var t = ts.get();
    switch (t.kind)
    {
        case"!": {
            if (left === 0)return 1;
            if (left < 0)
                throw("阶乘数须大于等于零，请重新输入");
            if (left !== Number(left))
                throw("阶乘数须为整数，请重新输入");
            var m = 1;
            for (var i = 1; i <= left; ++i)
                m *= i;
            return m;
        }
        default:
            ts.putback(t);
            return left;
    }
}

function primary() {
    //deal with +-num,lg(n),ln(n)
    var t = ts.get();
    switch (t.kind)
    {
        case"-":
            return -factorial();
        case"+":
            return factorial();
        case"n":
        {   //ln(d)
            var d = factorial();
            if (d > 0)
                return Number(Math.log(d))+1;
            else
                throw("ln底数需大于零，请重新输入");
        }
        case"g":
        {	//lg(d)
            var d = factorial();
            if (d > 0)
                return Math.log(d)/Math.log(10);
            else
                throw("lg底数需大于零，请重新输入");
        }
        default:
            ts.putback(t);
            return factorial();
    }
}

function fac(a) {
    if (a < 0)
        throw("阶乘数不可小于0，请重新输入");
    if (a === 0)
        return 1;
    var m = 1;
    for (var i = 1; i <= a; ++i)
        m *= i;
    return m;
}

function term() {
    var left = primary();
    var t = ts.get();
    while (true) {
        switch (t.kind)
        {
            case "^"://x^y
                left = Math.pow( left,primary());
                t = ts.get();
                break;
            case "*":
                left *= primary();
                t = ts.get();
                break;
            case "/": {
                var d = primary();
                if (d === 0)
                    throw("除数不可为0,请重新输入");
                left /= d;
                t = ts.get();
                break;
            }
            case "%": {
                var d = primary();
                var i1 = parseInt(left);
                var i2 = parseInt(d);
                if (i1 !== left || i2 !== d )
                    throw("取余无效：除数需为整数，请重新输入");
                if(i2===0)
                    throw("取余无效：除数不可为0，请重新输入");
                left = i1%i2;
                t = ts.get();
                break;
            }
            case "C": {   //mCn=m!/(n!*(m-n)))
                var n = primary();
                if (left < 0 )
                    throw("输入了无效的组合数"+left+"，请重新输入");
                if( n < 0 )
                    throw("输入了无效的组合数"+n+"，请重新输入");
                if(n > left )
                    throw("组合数无效，"+n+"，请重新输入");
                if (left != parseInt(left) || n != parseInt(n))
                    throw("输入了无效的组合数"+left+"，请重新输入");
                left = fac(left) /(fac(n)*fac(left - n));
                t = ts.get();
                break;
            }
            case "P": {	 //mPn=n!/m!
                var n = primary();
                if (left < 0 || n>left)
                    throw("输入了无效的排列数"+left+"，请重新输入");
                if (left !== parseInt(left) || n !== parseInt(n))
                    throw("输入了无效的排列数"+left+"，请重新输入");
                left = fac(left) / fac(left-n);
                t = ts.get();
                break;
            }
            default:
                ts.putback(t);
                return left;
        }
    }
}

function expression(){
    var left = term();
    var t = ts.get();
    while (true) {
        switch (t.kind) {
            case "+":
                left += term();
                t = ts.get();
                break;
            case "-":
                left -= term();
                t = ts.get();
                break;
            default:
                ts.putback(t);
                return left;
        }
    }
}

function $(id){
    return document.getElementById(id)
};


var Plot = {
    container: null, //画布
    ox: 500, //原点x
    oy: 300, //原点y
    baseLineColor: 'black', //坐标轴颜色
    brushColor: 'red', //画笔颜色
    brushWeight: 2, //画笔粗细

    baseLineX: null, // baseLineX 和 baseLineY 用于坐标移位
    baseLineY: null,

    //初始化方法
    init: function (containerId, ox, oy, baseLineColor, brushColor, brushWeight) {
        if ($(containerId)) {
            Plot.container = $(containerId);
        } else {
            alert('你必须制定一个区域作为画布！');
            return;
        }
        if ((typeof ox) == 'number') {
            Plot.ox = ox;
        }
        if ((typeof oy) == 'number') {
            Plot.oy = oy;
        }
        Plot.baseLineColor = baseLineColor;
        Plot.brushWeight = brushWeight;
        Plot.brushColor = brushColor;
        Plot.drawCoordinate();
    },


    // 画坐标轴
    drawCoordinate: function () {
        var baseLineX = document.createElement('div');
        baseLineX.style.position = 'absolute';
        baseLineX.style.left = 0;
        baseLineX.style.top = Plot.oy;
        baseLineX.style.fontSize = '2px';
        baseLineX.style.height = '1px';
        baseLineX.style.width = '100%';
        baseLineX.style.overflow = 'hidden';
        baseLineX.style.backgroundColor = Plot.baseLineColor;
        Plot.container.appendChild(baseLineX);
        Plot.baseLineX = baseLineX;

        var baseLineY = document.createElement('div');
        baseLineY.style.position = 'absolute';
        baseLineY.style.left = Plot.ox;
        baseLineY.style.top = 0;
        baseLineY.style.fontSize = '2px';
        baseLineY.style.height = '100%';
        baseLineY.style.width = '1px';
        baseLineY.style.overflow = 'hidden';
        baseLineY.style.backgroundColor = Plot.baseLineColor;
        Plot.baseLineY = baseLineY;
        Plot.container.appendChild(baseLineY);
    },

    //清理画布
    clean: function () {
        Plot.container.innerHTML = "";
        Plot.drawCoordinate();
    },

    //画点，相对原点
    drawDot: function (x, y) {
        var dot = document.createElement('div');
        dot.style.left = Plot.ox + x + 'px';
        dot.style.top = Plot.oy - y + 'px';
        dot.style.height = 1.7;
        dot.style.width = 1.7;
        dot.style.position = 'absolute';
        dot.style.fontSize = '1px';
        dot.style.backgroundColor = Plot.brushColor;
        dot.style.overflow = 'hidden';
        Plot.container.appendChild(dot);
        dot = null;
    },
}


